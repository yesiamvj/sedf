  <?php session_start(); 
  if(empty($_SESSION['user_id']) || empty($_SESSION['user_name']))
 {
     header("location:index.php");
 }
 else
{
        
        $viewer_id=$_SESSION['user_id'];
        $user_name=$_SESSION['user_name'];
        include 'subtitle_bar.php';
        $user_id=$_GET['user'];
        echo '
    
    <link rel="stylesheet" href="../web/'.$_SESSION['css'].'thePost.css"/> 
   <link rel="stylesheet" href="../web/'.$_SESSION['css'].'profile_newcss.css"/> 
   
      <link rel="stylesheet" href="../web/'.$_SESSION['css'].'theBigThate.css"/> 
   
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="../web/thePost.js" type="text/javascript"></script>';
        
        
        
         require 'mysqli_connect.php';
         include 'title_bar.php';
         
        echo '<div id="content-full">
           
            <div class="PagePinnedTtl" id="PagePinnerTitle" >
                <div id="pagepinnerid"></div>
                <div class="closePinnedTab" onclick="$(\'#PagePinnerTitle\').slideUp()" >X</div>
            </div>
            <div id="trgt_div"></div>
            <div class="TheWhatsUp" >
            <div id="TheWhatsUpAuditoriu" style="display:none;"><div id="post_contents"></div></div>
                <div class="ThePostSafetyLayerForResponders" onmouseover="hidePostResponders()" ></div>
                <div class="TheWhatsUpCenterCont">
                    <!-- post loop starts-->
                   ';
        function allpost($btm_meme,$top_meme,$thum_nails,$tot_files,$post_pdfs,$post_audios,$post_videos,$post_files,$shared_name,$shared_user_name,$shared_time,$post_images,$pvs,$post_loc,$post_feel,$post_feelwhile,$officiale,$with_ppl_user_name,$with_ppl_name,$poster_user_name,$p_pic,$post_id,$poster_id,$post_caption,$post_time,$poster_name,$imgc,$cnt,$lc,$ulc,$ratc,$cmcnt,$dncnt,$shrcnt,$mylike,$myunlike,$myrate,$likeres,$unlikeres,$dwnres,$cmntres,$shareres,$rateres,$ctgry,$discr,$shared_with_userid,$shared_to_me,$c_name,$shared_userid,$tot_num_post, $next_postid,$prev_postid,$page_name,$my_category,$page_id,$tot_cnt)
        {
               echo '<div class="a_complete_post" id="a_full_post'.$post_id.'"> <div id="fornextpost'.$cnt.'"></div>
                          <div class="ThePostExtraBench" id="TPEB_'.$cnt.'" style="display: none;">
                        
                        <div class="TPEB_Itm" onclick="checkPrevPostExisting'.$prev_postid.'()">
                            <div class="prevDriver" title="Show previous post" ></div>
                        </div>
                        <div class="TPEB_Itm" title="Float" onclick="pinItOnTop('.$post_id.')" >
                            <img src="icons/pExt/cloud.png" />
                            <input type="hidden" id="Post_Cloud_'.$post_id.'" value="'.$post_id.'" />
                        </div>
                        <div class="TPEB_Itm" title="Add to favourites" onclick="add_to_post_fav('.$post_id.')">
                            <img src="icons/pExt/fav.png" />
                        </div>
                        <div class="TPEB_Itm" title="Report This Post" onclick="report_this_post('.$post_id.')">
                            <img src="icons/pExt/report.png"  />
                        </div>
                        <div class="TPEB_Itm"  onclick="checkNextPostExisting'.$next_postid.'()">
                            <div class="nextDriver" title="Show next post"></div>
                        </div>
	      <div id="thispostid'.$post_id.'" style="font-size:0px;" >printed</div>
                           <script>
                                            function checkNextPostExisting'.$next_postid.'(){
                                           
                                        if($(\'#thispostid'.$next_postid.'\').html()==="printed"){
                                             window.location.assign(\'#thispostid'.$next_postid.'\');
                                            }
                                                else{
                                               
                                                    nextpost(0,'.$cnt.','.$next_postid.',\'#fornextpost'.$cnt.'\','.$tot_num_post.');
                                            }

                                        }
                                            function checkPrevPostExisting'.$prev_postid.'(){
                                        if($(\'#thispostid'.$prev_postid.'\').html()==="printed"){
                                             window.location.assign(\'#thispostid'.$prev_postid.'\');
                                            }
                                                else{
                                                
                                                    nextpost(1,'.$cnt.','.$prev_postid.',\'#for_my_prevpost'.$cnt.'\','.$tot_num_post.');
                                            }

                                        }
                                        </script>
                    </div>';
               if($shared_name!==0 )
               {
	     echo '	     <div class="ThePostSharedBy">
                        <div class="ThePostSharerName">
                            <a href="../'.$shared_user_name.'">'.$shared_name.'</a> <span class="TPShare_Desc">Shared this post</span>
                            <span class="TPShare_Time">@ '.$shared_time.' </span>
                        </div>
                    </div>';
               }

	            echo '
                    <div class="ThePostHolder" id="ThisPostId_'.$post_id.'" onmouseover="showPostRespPane('.$cnt.');see_this_pos('.$post_id.')"  >
                        
                        <div class="ThePostArrow"></div>
                        <div class="ThePostExtra" onclick="$(\'#TPEB_'.$cnt.'\').slideToggle();" >
                            <span class="TPE_Dots">.</span>
                            <span class="TPE_Dots">.</span>
                            <span class="TPE_Dots">.</span>
                        </div>
                        <div class="ThePostToppper">
                           <div class="ThePostOwner">
                            <div class="PosterProfPic">
                                <img src="'.$p_pic.'" class="img_PosterFace" alt=""/>
                            </div>
	           ';
               if($officiale==1)
               {
	     
	            
	     echo '<div class="PosterName">
                                <a href="../'.$poster_name.'" class="PosterUserLink" >  '.$poster_name.' </a> 
		     ';
	           echo ' <div class="OfficialCaption">
                                    '.  ($post_feel).'
                                </div>'; 
	     echo '
		      
                            </div>
                           ';
	     
               }else
               {
	     if($page_id!=="0")
	     {
	            $poster_name=$page_name;
	            $poster_user_name=$page_name;
	            
	     }
	 echo '             <div class="PosterName">
                                <a href="../'.$poster_user_name.'" class="PosterUserLink" >  '.$poster_name.' </a> ';
	               if(!empty($post_feel))
	               {
		     if($officiale==1)
		     {
		            echo ' <div class="OfficialCaption">
                                    '.  ($post_feel).'
                                </div>';
		           
		     }else
		     {
		             echo ' <span class="PosterFeeling"><font color="grey">'.  htmlentities($post_feel).'</font> <span class="postFeelType"> while posting </span> </span>
                               ';  
		     }
		  
	               }
	               if(!empty($post_feel) && !empty($post_feelwhile))
	               {
		echo '<span class="PF_and">&</span> 
		        <span class="PosterFeeling"> '.htmlentities($post_feelwhile).'<span class="postFeelType"> by posting </span> </span>
                               
                                '; 
		
	               }elseif (!empty ($post_feelwhile)) {
	           echo '    <span class="PosterFeeling">'.htmlentities($post_feelwhile).' <span class="postFeelType">  ';
	           if($officiale!==1)
	           {
		 echo 'by posting 
                               '; 
	           }
		
	    }
	    $at="";
	    if($officiale==1)
	    {
	           $at="";
	    }else
	    {
	           if(!empty($post_loc))
	           {
		$at="at"; 
	           }
	           
	    }
                                echo '</span> </span><span class="PF_and">'.$at.'</span>
                                <span class="PosterLocation">
                                    <a href="https://www.google.com/search?q='. htmlentities($post_loc).'" target="_blank" > '.  htmlentities($post_loc).' </a> 
                                </span>
                                <div class="PostedWith">
                                    ';
		  if(count($with_ppl_name)>0)
		  {
		           echo'<span class="PF_and">with</span>';
		
		   for($t=1;$t<=count($with_ppl_name);$t++)
		  {
		         echo '<div class="PWI_name">
		        <a href="../'.$with_ppl_user_name[$t].'">'.$with_ppl_name[$t].'</a> 
		    </div>';
		         if($t>4)
		         {
		                $mean=count($with_ppl_name)-$t;
		                echo '
                                   <div class="PWI_more">+ '.$mean.'</div>';
		                break;
		         }
                                   
		  }
		   
		  }
		 
		 echo '
                                    
                                </div>
                               
                            </div>
                           
                            ';
	     
               }
               
              	 echo '
                        </div>
                        <div class="ThePostDetails">
                            <div class="PosterTime">
                                <div class="PosterSignature" title="User ID : '.$poster_id.'" > <a href="../'.$poster_user_name.'"> <span class="sf_TmDoller" >$</span>'.$poster_user_name.'</a></div> 
                                <div class="ThePostId">'.$post_id.'</div> @  '.$post_time.'
                            </div>
                        </div>';
	 if(strlen($post_caption)>0)
	 {
	      echo ' <div class="ThePostCaption">';  
	      if($officiale!=1)
	 {
	        echo ''.htmlentities($post_caption).'';
	 }else
	 {
	        if($post_caption!=="")
	        {
	        echo '  <div class="OfficialPostCaption"> 
                                  '.$post_caption.' 
                                </div>';       
	        }else
	        {
	              echo '  <div class="ThePostCaption"> 
                                  '.$post_caption.' 
                                </div>';    
	        }
	               
	        
	 }
                           
                  
	 echo ' </div>';
	 
	 }
                       
	        echo '
                        </div>
                        ';
	        
	        
	        //media
	        if(count($post_videos)>0)
	        {
	             $media_click='onclick="//showBigScreen(\''.$post_id.'\',\''.count($post_images).'\',\'1\',\''.$next_postid.'\','.$tot_num_post.')"'; 
	        }else
	        {
	               $media_click="";
	        }
	     
	        echo '
                        <div class="ThePostMediaHolder" '.$media_click.' id="post_media'.$post_id.'" onclick="$(\'#TheWhatsUpAuditorium\').fadeIn();$(\'#post_contents\').html($(\'#a_full_post'.$post_id.'\').clone()).fadeIn();$(\'#audi_tools'.$post_id.'\').fadeIn();$(\'#theaterActTools'.$post_id.'\').fadeIn();" >';
	        if(count($post_images)==1)
	        {
	               echo ''.$top_meme.'';
	               echo ' <img src="'.$post_images[1].'" onclick="showBigScreen(\''.$post_id.'\',\''.count($post_images).'\',\'1\',\''.$next_postid.'\')" class="img_ThePost" />';
	               echo ''.$btm_meme.'';
	               }
	        if(count($post_images)==2)
	        {
	               echo '  <div class="doubleImgeHolder"   onclick="$(\'#wch_clkd\').val(2);">
                                <div class="TPMH_DIH_First" style="background-image: url(\''.$post_images[1].'\')" onclick="showBigScreen(\''.$post_id.'\',\''.count($post_images).'\',\'1\',\''.$next_postid.'\','.$tot_num_post.')" ></div>
                                <div class="TPMH_DIH_First" style="background-image: url(\''.$post_images[2].'\')" onclick="showBigScreen(\''.$post_id.'\',\''.count($post_images).'\',\'2\',\''.$next_postid.'\','.$tot_num_post.')" ></div>
                               
                            </div>
                            ';
	        }
	        if(count($post_images)==3)
	        {
	              echo  '      <div class="tripleImgeHolder" onclick="$(\'#wch_clkd\').val(3);" >
                                <div class="TPMH_TIH_First" style="background-image: url(\''.$post_images[1].'\')" onclick="showBigScreen(\''.$post_id.'\',\''.count($post_images).'\',\'1\',\''.$next_postid.'\','.$tot_num_post.')" ></div>
                                <div class="TPMH_TIH_Holder">
                                    <div class="TPMH_TIH_First" style="background-image: url(\''.$post_images[2].'\')" onclick="showBigScreen(\''.$post_id.'\',\''.count($post_images).'\',\'2\',\''.$next_postid.'\','.$tot_num_post.')" ></div>
                                <div class="TPMH_TIH_First" style="background-image: url(\''.$post_images[3].'\')" onclick="showBigScreen(\''.$post_id.'\',\''.count($post_images).'\',\'3\',\''.$next_postid.'\','.$tot_num_post.')" ></div>
                                </div>
                                
                               
                            </div>';
	        }
	        if(count($post_images)==4)
	        {
	               echo '     <div class="fourseImgeHolder"  onclick="$(\'#wch_clkd\').val(4);" >
                                <div class="TPMH_TIH_First" style="background-image: url(\''.$post_images[1].'\')" onclick="showBigScreen(\''.$post_id.'\',\''.count($post_images).'\',\'1\',\''.$next_postid.'\','.$tot_num_post.')" ></div>
                                <div class="TPMH_TIH_Thrice_Holder">
                                    <div class="TPMH_TIH_First" style="background-image: url(\''.$post_images[2].'\')" onclick="showBigScreen(\''.$post_id.'\',\''.count($post_images).'\',\'2\',\''.$next_postid.'\','.$tot_num_post.')" ></div>
                                <div class="TPMH_TIH_First" style="background-image: url(\''.$post_images[3].'\')" onclick="showBigScreen(\''.$post_id.'\',\''.count($post_images).'\',\'3\',\''.$next_postid.'\','.$tot_num_post.')" ></div>
                                <div class="TPMH_TIH_First" style="background-image: url(\''.$post_images[4].'\')" onclick="showBigScreen(\''.$post_id.'\',\''.count($post_images).'\',\'4\',\''.$next_postid.'\','.$tot_num_post.')" ></div>
                                </div>
                                
                               <div onclick="showBigScreen(\''.$post_id.'\',\''.count($post_images).'\',\'1\',\''.$next_postid.'\')" class="ThePostMediaMoreImage" >show all '.  count($post_images).' images</div>
                            </div>';
	        }
	        if(count($post_images)==0)
	        {
	               if(count($post_videos)>0)
	               {
		     if(strlen($thum_nails[0])>1)
		     {
		            $thum_nail=$thum_nails[0];
		     }  else {
		     $thum_nail="";       
		     }
		     echo '<video src="'.$post_videos[1].'" preload="none" onclick="//showBigScreen(\''.$post_id.'\',\''.count($post_images).'\',\'1\',\''.$next_postid.'\','.$tot_num_post.')" class="img_ThePost" controls poster="'.$thum_nail.'" /></video>';
	               }
	        }
	       
	        if(count($post_images==0) && count($post_videos==0))
	        {
	               if(count($post_audios)>0)
	               {
		echo '<audio src="'.$post_audios[1].'"  preload="none" controls/></audio>';     
	               }
	               
	        }
	        if(count($post_images)==0 &&  count($post_videos)==0)
	        {
	               
	               
	        }
	
	          if(count($post_pdfs)>0 || count($post_files)>0)
	               {
		if(count($post_pdfs)==1 )
		   {
		     $name=strpos($post_pdfs[1],"postpdfs/")+15;
	               $pdf_name=substr($post_pdfs[1],$name,  strlen($post_pdfs[1]));
	               $file="PDF";
	                     
		   }
		  
		   if( count($post_files)>0)
		   {
		          $download=$post_files[1];
		      $name=strpos($post_files[1],"postfiles/")+15;
	               $pdf_name=substr($post_files[1],$name,  strlen($post_files[1]));
	                       $file="File";  
		      if(count($post_pdfs)>1)
		            {
			 $hint="+ $mean files";  
		            }else
		            {
			 $hint=""; 
		            }
		      
		   }
		    
		     if(count($post_pdfs)>0)
		     {
		            $download=$post_pdfs[1];
		            $mean=(count($post_pdfs)+count($post_files))-1;
		            if(count($post_pdfs)>1)
		            {
			 $hint="+ $mean files";  
		            }else
		            {
			 $hint=""; 
		            }
		           
		     }else
		     {
		            
		     }
		     echo ' <div class="ThePostPdfFileNameHolder" >
                                <div class="TP_PDF_Logo">
                                 '.$file.'
                                </div>
                                <div class="TP_PDF_Dets">
                                    <div class="TP_PDF_Name">
                                     '.htmlentities($pdf_name).'  '.$hint.'
                                    </div>
                                    <div class="TP_PDF_size">
                                       <a href="'.htmlentities($post_files[1]).'" target="_blank"><div class="TP_PDF_Preview">Preview</div></a> <a href="'.htmlentities($download).'" download="'.htmlentities($download).'"><div class="TP_PDF_download">Download</div></a>
                                    </div>
                                </div>
                                
                                
                            </div>';
	               }
	     
	        
	echo '<input type="hidden" value="" id="wch_clkd"/>';               
                       echo ' </div>
                        <div class="ThePostStatusHolder">
                            ';
	  if($likeres==1)
                        {
	         echo '<div class="TPSH_Itm">';
                        if($mylike==1)
                        {

                            echo '<img class="ico_PostResp" onclick="Likedone(1,\'#like'.$cnt.'\','.$post_id.','.$cnt.');incread_count(\'.like_cnt'.$post_id.'\',1)"  id="like'.$cnt.'" src="icons/post-sf-liked.png" alt="like"/> ';
                           
                        }else
                        {
                        echo '<img class="ico_PostResp" onclick="Likedone(1,\'#like'.$cnt.'\','.$post_id.','.$cnt.');incread_count(\'.like_cnt'.$post_id.'\',1)"  id="like'.$cnt.'" src="icons/post-sf-like.png" alt="like"/> ';

                        }
                        }
	       echo '</div>';
	       echo '<div class="TPSH_Itm">';
                        if($unlikeres==1)
                        {

                        if($myunlike==1)
                        {
                            
                            echo' <img class="ico_PostResp" onclick="Likedone(0,\'#unlike'.$cnt.'\','.$post_id.','.$cnt.');incread_count(\'.unlike_cnt'.$post_id.'\',0)"  id="unlike'.$cnt.'" src="icons/post-sf-unliked.png" alt="Unlike"/>';
                            
                        }else
                        {
                            
                            echo' <img class="ico_PostResp" onclick="Likedone(0,\'#unlike'.$cnt.'\','.$post_id.','.$cnt.');incread_count(\'.unlike_cnt'.$post_id.'\',0)"  id="unlike'.$cnt.'" src="icons/post-sf-unlike.png" alt="Unlike"/>
                            ';
                        }
                        }
	       echo '</div>';
                        if($rateres==1)
                        {
                            if($myrate==0)
                        {

                           echo'                        <div class="TPSH_Itm">
                                <img onclick="postRated(1,this.id,'.$post_id.','.$cnt.')" id="'.$cnt.'rated1" class="TP_rateIcons"  src="icons/post-sf-emptyRate.png" alt="rate1"/>
                                <img onclick="postRated(2,this.id,'.$post_id.','.$cnt.')" id="'.$cnt.'rated2"  class="TP_rateIcons" src="icons/post-sf-emptyRate.png" alt="rate2"/>
                                <img onclick="postRated(3,this.id,'.$post_id.','.$cnt.')" id="'.$cnt.'rated3"   class="TP_rateIcons" src="icons/post-sf-emptyRate.png" alt="rate3"/>
                                <img onclick="postRated(4,this.id,'.$post_id.','.$cnt.')" id="'.$cnt.'rated4"  class="TP_rateIcons" src="icons/post-sf-emptyRate.png" alt="rate4"/>
                                <img onclick="postRated(5,this.id,'.$post_id.','.$cnt.')" id="'.$cnt.'rated5"  class="TP_rateIcons" src="icons/post-sf-emptyRate.png" alt="rate5"/>
                   
                            </div>
                        ';
                        }else
                        {

                                        echo'<div class="TPSH_Itm">';
                              for($nt=1;$nt<=$myrate;$nt++)
                                    {
                                        
                                       echo'<img class="TP_rateIcons" onclick="postRated('.$nt.',this.id,'.$post_id.','.$cnt.')" id="'.$cnt.'rated'.$nt.'" src="icons/post-Qrated-'.$myrate.'.png" alt="'.$myrate.'"/></span>';
                                 
                                    }
                                    for($nt=$myrate+1;$nt<=5;$nt++)
                                    {

                                        echo'<img class="TP_rateIcons" onclick="postRated('.$nt.',this.id,'.$post_id.','.$cnt.')"   id="'.$cnt.'rated'.$nt.'" src="icons/post-sf-emptyRate.png" alt="'.$myrate.'"/>';
                                    }
                                    echo'</div>';
                        }
                        }
                        
	       if($officiale==0)
	       {
	        if($cmntres==1)
	        {
	               
	 echo '    <div class="TPSH_Itm" onclick="ViewComment(\'#commentContentFull'.$cnt.'\')" >
                                <img src="icons/postSts/comments_2.png" />
                            </div>';
	        }
	       }else
	       {
	        
	 echo '         
                            <div class="TPSH_Itm" onclick="ViewComment(\'#commentContentFull'.$cnt.'\')" >
                                <img src="icons/postSts/comments_2.png" />
                            </div>';      
	       }
	       if($officiale==0)
	       {
	              if($dwnres==1)
	              {
		         echo '
                            <div class="TPSH_Itm" onclick="downloadpost('.$cnt.','.$post_id.')">
                                <img src="icons/post-media-download.png" />
                            </div>';
	              }
	       }else
	       {
	                       echo '
                            <div class="TPSH_Itm" onclick="downloadpost('.$cnt.','.$post_id.')">
                                <img src="icons/post-media-download.png" />
                            </div>';
	       }
	if($officiale==0)
	{
	       if($shareres==1)
	       {
	               echo '
                            <div class="TPSH_Itm" onclick="open_share_window('.$cnt.','.$post_id.')" >
                                <img src="icons/post-sf-share.png" />
                            </div>';
	       }
	}else
	{
	         echo '
                            <div class="TPSH_Itm" onclick="open_share_window('.$cnt.','.$post_id.')" >
                                <img src="icons/post-sf-share.png" />
                            </div>';
	}
	       
	
	 echo '
	           <div id="load_share_window">
	           <div id="for_share_widow" ></div>
                         </div>
	                 <input type="hidden" id="tot_cmnt_smiley'.$tot_cnt.'" value="1"/>
                        <div id="commentContentFull'.$cnt.'" class="commentContentFull">
	              <div class="newCommentHolder">
                            <span class="commentTitle" id="commentTitle'.$tot_cnt.'" title="Click to view All Comments" onclick="viewprecmnt(\'#previousComments'.$tot_cnt.'\','.$post_id.','.$tot_cnt.')">Comments &nbsp;&nbsp;&nbsp;<img style="width: 10px;height:10px;" src="icons/expnd-dwn.png" alt="down"/></span><span id="refresh_cmnt'.$cnt.'" onclick="refresh_cmnt('.$post_id.',\'#previousComments'.$tot_cnt.'\',\''.$tot_cnt.'\')">New</span>
                                <form method="post">
                                    <input id="'.$tot_cnt.'sf-commentInput" class="sf-commentInput" type="text" placeholder="What do you think?" />
                                    <div style="display: inline-block">
                                        <input type="color" class="colorComment" id="'.$cnt.'colorComment" onchange="colortyped(\'#'.$cnt.'colorComment\',\'#sf-commentInput'.$cnt.'\')"/>
                                    <input type="button" onmouseover="mouseOnColorCmnt(1)" onmouseout="mouseOutColorCmnt(1)" onclick="$(\'#'.$cnt.'colorComment\').click();"  class="colorCmntIcon" id="colorCmntIcon" value="A"/>
                                    <input type="file" name="uploadme'.$cnt.'" class="attachCmnt" id="attachCmnt'.$tot_cnt.'" style="display:none" />
                                    
                                     <div class="forCmntTtArrowUtil" id="forCmntTtArrowUtil"></div>
                                    <div class="toolTipCmntUtils" id="toolTipCmntUtils">Add a color to your comment</div>
                                    
                                    </div>
                                     <div class="for_cmnt_smiley" style="display:none;" id="for_show_smiley'.$tot_cnt.'"></div>
                                   
                                    <div class="forCommentAdds" id="forCommentAdds'.$tot_cnt.'">
                                        <ol>
                                            <li ><img onclick="show_smileys(\''.$tot_cnt.'\',\''.$post_id.'\',\'#for_show_smiley'.$tot_cnt.'\')" onmouseover="mouseOnCmntAttch(1)" onmouseout="mouseOnCmntAttch(3)" id="smileyHead'.$cnt.'" class="smileyHead" src="icons/test-smiley.png" alt="smiley"/></li>
                                            <li><img onclick="$(\'.attachCmnt'.$cnt.'\').click();" onmouseover="mouseOnCmntAttch(2)" onmouseout="mouseOnCmntAttch(3)" id="smileyHead'.$cnt.'" class="smileyHead" src="icons/test-atch.png" alt="smiley"/></li>
                                        </ol>
                                   <div class="forCmntArrow" id="forCmntArrow"></div>
                                        <div class="forCmntTtArrow" id="forCmntTtArrow"></div>
                                        <div class="toolTipCmntAdd" id="toolTipCmntAdd"> Add an Attachment</div>
                                      </div>
                                    
                                    <div style="display: inline">
                                    <input onmouseover="mouseOnColorCmnt(2)" onmouseout="mouseOutColorCmnt(2)" type="button" onclick="showOptions(\'#forCommentAdds'.$tot_cnt.'\')" class="attachCmntIcon" value="A"/>
                                    <input class="submitCmnt" type="button" onclick="uploadcomment('.$post_id.',0,0,'.$tot_cnt.')" value="Comment"/>
                                    </div>
                                </form>
                                <div><span id="smiley_cls_btn_cmnt'.$tot_cnt.'" class="smiley_cls_btn_cmnt" style="display:none;" onclick="$(\'#smiley_preview'.$tot_cnt.'\').html(\'\');">X</span><div id="smiley_preview'.$tot_cnt.'" class="smiley_preview"></div></div>
                               <div id="totlprevcmnts'.$cnt.'" class="totlprevcmnts"> <div class="for_new_cmnt'.$cnt.'" ></div>
                            </div>
		
                            
                                </div>
	                <div class="previousComments" id="previousComments'.$tot_cnt.'">
                                </div>
                                
                            </div>
                        </div>
                        
                    </div>
                   
	           <!-- post dets -->
	
<input type="hidden" value="1" id="wch_clkd"/>
                      <div class="ThePostRespDetHold" id="PostResponsePane_PID_'.$cnt.'" style="display: none;" >
                            <div class="TPRD_Ttl">
                                Post Id :<span class="TPRD_PID">'.$post_id.'</span> 
                            </div>
                            <div class="TPRD_Itm" id="Post_Likers_PID" name="'.$post_id.'" title="'.$cnt.'" onclick="showPostLikers('.$cnt.')"  >
                                    <div class="TPRD_ItmInner">
                                        <div class="TPRD_RespCount" id="ThePostLikes">
                                        <span class="like_cnt'.$cnt.'" >'.$lc.'</span>
                                    </div>
                                    <div class="TPRD_RespItmName" >
                                        Likes
                                    </div>
                                    </div>
                                    
                                </div>
                                <div class="TPRD_Itm">
                                    <div class="TPRD_ItmInner" >
                                    <div class="TPRD_RespCount" id="ThePostUnlikes" >
                                        <span class="unlike_cnt'.$cnt.'">'.$ulc.'</span>
                                    </div>
                                    <div class="TPRD_RespItmName"  >
                                        Hates
                                    </div>
                                    </div>
                                  
                                </div>
                                <div class="TPRD_Itm"  id="Post_Raters_PID" title="'.$cnt.'" name="'.$post_id.'" onclick="showPostRaters('.$cnt.')">
                                    <div class="TPRD_ItmInner"   >
                                    <div class="TPRD_RespCount" >
                                        <img class="TPRD_RatedIcon" id="change_rate_icon'.$post_id.'" src="icons/post-rated-'.$myrate.'.png" />
                                    </div>
                                    <div class="TPRD_RespItmName">
                                        Rating
                                    </div>
                                    </div>
                                   
                                </div>
                                <div class="TPRD_Itm" title="'.$cnt.'" id="Post_Commenters_PID" name="'.$post_id.'" onclick="showPostCommenters('.$cnt.')">
                                    <div class="TPRD_ItmInner"   >
                                    <div class="TPRD_RespCount" id="ThePostComments" >
                                       <span class="cmcnt'.$cnt.'">'.$cmcnt.'</span>
                                    </div>
                                    <div class="TPRD_RespItmName">
                                        Comments
                                    </div>
                                    </div>
                                    
                                </div>
                                <div class="TPRD_Itm" title="'.$cnt.'" id="Post_Sharers_PID" name="'.$post_id.'"  onclick="showPostSharers('.$cnt.')">
                                    <div class="TPRD_ItmInner"  >
                                    <div class="TPRD_RespCount" id="ThePostShares" >
                                        <span class="share_cnt'.$cnt.'">'.$shrcnt.'</span>
                                    </div>
                                    <div class="TPRD_RespItmName">
                                        Shares
                                    </div> 
                                    </div>
                                  
                                </div>
                                <div class="TPRD_Itm">
                                    <div class="TPRD_ItmInner">
                                    <div class="TPRD_RespCount" id="ThePostViews" >
                                       '.$pvs.'
                                    </div>
                                    <div class="TPRD_RespItmName">
                                        Views
                                    </div>
                                    </div>
                                   
                            </div>
                        </div>
	       
	      <div class="ThePostPreviousResponders" id="Post_Likers_PID_'.$cnt.'"  >
                         
                            
                        </div>
	       
	       <div class="ThePostPreviousResponders" id="Post_Raters_PID_'.$cnt.'"  >
                       
                        </div>
	       
                        <div class="ThePostPreviousResponders" id="Post_Commenters_PID_'.$cnt.'"  >
                            
                        </div>
	       
	       
	       <div class="ThePostPreviousResponders" id="Post_Sharers_PID_'.$cnt.'"  >
                            
                        </div>
	       
	       <div class="ThePostPreviousResponders" id="Post_Withers_PID_'.$cnt.'" >
                           
                        </div>
	      
	   
                        <div id="dwnresult" style="display:none"></div>
                          <div id="for_my_prevpost'.$cnt.'"></div>
                     </div>
                      ';
        }
        
     
        $ulc=0;
$lc=0;
$dncnt=0;
$cmcnt=0;
$shrcnt=0;
$ratc=0;
                      $shr_ct=0;
                    $aps="SELECT post_id as pid,user_id as uid,allpeople as ap,share as shr,page_id as p,officiale as of_cl from post_permision where user_id=$user_id  order by post_id desc limit 5";
                        $runap=mysqli_query($dbc,$aps);
                        if($runap)
                        {
                            if(mysqli_num_rows($runap)>0)
                            {
                                $cnt=0;
                                $tot_cnt=0;
                           $tot_num_post=  mysqli_num_rows($runap); 
                                while ($rowofap=mysqli_fetch_array($runap,MYSQLI_ASSOC))
                                {
                                    $tot_cnt=$tot_cnt+1;
                                    $cnt=$cnt+1;
		  $officiale=$rowofap['of_cl'];
                                      $shared_with_userid=0;
                                          $shared_to_me=0;
                                           $shared_userid=0;
                                           $page_id=$rowofap['p'];
                                           $c_name=0;
		           $page_name="";
		          
		         if($page_id!=0)
		         {
		         $qpage="select page_name as p from pages where page_id=$page_id";
		         $rpage=  mysqli_query($dbc, $qpage);
		         if($rpage)
		         {
		              
		                if(mysqli_num_rows($rpage)>0)
		                {
			      $ro_pg=  mysqli_fetch_array($rpage,MYSQLI_ASSOC);
			      $page_name=$ro_pg['p'];
		                }
		         }
		         }
		  $post_id=$rowofap['pid'];
		         $orig_post_id=$post_id;
                                           $share=$rowofap['shr'];
		  
		        $shared_name=0;
		        $shared_user_name=0;
		        $shared_time=0;
		        $shared_user_id=0;
		        $poster_id=$rowofap['uid'];
		        $orig_poster_id=$poster_id;
                                    $allppl=$rowofap['ap'];
                                          if($share!=0 )
                                          {
                                                  
                                      $qshr="select post_id as p from post_share where share_id=$share";
		    $rshr=  mysqli_query($dbc, $qshr);
		    if($rshr)
		    {
		           if(mysqli_num_rows($rshr)>0)
		           {
			 $shr_row=  mysqli_fetch_array($rshr,MYSQLI_ASSOC);
			 $post_id=$shr_row['p'];
			 $shr_q="select user_id as u from post_permision where post_id=$post_id";
			 $r_shr=  mysqli_query($dbc, $shr_q);
			 if($r_shr)
			 {
			        $rof=  mysqli_fetch_array($r_shr,MYSQLI_ASSOC);
			        $poster_id=$rof['u'];
			 }
		           }
		    }
		   
		    $qpf="select post_time as t,user_id as u from postforall where post_id=$orig_post_id";
		    $rpf=  mysqli_query($dbc, $qpf);
		    if($rpf)
		    {
		           if(mysqli_num_rows($rpf)>0)
		           {
			 $shr_df=  mysqli_fetch_array($rpf,MYSQLI_ASSOC);
			 $shared_user_id=$shr_df['u'];
			 $shared_time=$shr_df['t'];
		           }
		    }
		     $selemail="select username as em from users where user_id=$shared_user_id";
                                                             $rinemail=mysqli_query($dbc,$selemail);
                                                             if($rinemail)
                                                             {
				
                                                                 $rowsemail=mysqli_fetch_array($rinemail);
                                                                 $shared_user_name=$rowsemail['em'];
                                                             }
			        
			           $selemail="select first_name as em from basic where user_id=$shared_user_id";
                                                             $rinemail=mysqli_query($dbc,$selemail);
                                                             if($rinemail)
                                                             {
                                                                 $rowemail_shr=mysqli_fetch_array($rinemail);
                                                                 $shared_name=$rowemail_shr['em'];
                                                             }
		 
                                      
                                          }
                                   
                                    
           $qn="select post_id as p from post_permision where user_id=$poster_id and post_id>=$post_id and post_id!=$post_id  order by post_id asc";
          $qp="select post_id as p from post_permision where user_id=$poster_id and post_id<=$post_id and post_id!=$post_id  order by post_id desc";
                $rn=  mysqli_query($dbc,$qn);
                $rp=mysqli_query($dbc,$qp);
                if($rn && $rp)
                {
                    if(mysqli_num_rows($rn)>0)
                    {
                        $rnp=  mysqli_fetch_array($rn,MYSQLI_ASSOC);
                        $next_postid=$rnp['p'];
                    }else
                    {
                  
                    
                $q="select post_id as p from post_permision where user_id=$poster_id limit 1";
                $r=  mysqli_query($dbc, $q);
                if($r)
                {
                    if(mysqli_num_rows($r)>0)
                    {
                        $rt=  mysqli_fetch_array($r,MYSQLI_ASSOC);
                        $next_postid=$rt['p'];
                    }
                }
                    }
                    if(mysqli_num_rows($rp)>0)
                    {
                        $rpp=  mysqli_fetch_array($rp,MYSQLI_ASSOC);
                        $prev_postid=$rpp['p'];
                    }else
                    {
                         
                    
                   $q="select post_id as p from post_permision where user_id=$poster_id order by post_id desc limit 1";
                    $r=  mysqli_query($dbc, $q);
                if($r)
                {
                    if(mysqli_num_rows($r)>0)
                    {
                        $rt=  mysqli_fetch_array($r,MYSQLI_ASSOC);
                        $prev_postid=$rt['p'];
                    }
                }
                    }
                }
                
                                          $with_ppl_name=array();
		        $with_ppl_user_name=array();
                                        $wppl="select withuser_id as wuid from post_forsomeppl where post_id=$post_id";
                                        $rwppl=mysqli_query($dbc,$wppl);
                                        if($rwppl)
                                        {
                                             $totwusers=0;
		             $t_usr_nm=0;
                                            if(mysqli_num_rows($rwppl)>0)
                                            {
                                               
                                                while($rowppl=mysqli_fetch_array($rwppl,MYSQLI_ASSOC))
                                                {
                                                    $withusers_id=$rowppl['wuid'];

                                                    if(!empty($withusers_id))
                                                    {
                                                        $totwusers=$totwusers+1;
                                                     $uname="select c_name as fname from contacts where user_id=$user_id and  cu_id=$withusers_id";
                                                     $runnm=mysqli_query($dbc,$uname);
                                                     if($runnm)
                                                     {
                                                         if(mysqli_num_rows($runnm)>0)
                                                         {
                                                             $rownm=mysqli_fetch_array($runnm);
                                                             $with_ppl_name[$totwusers]=$rownm['fname'];
                                                         }else{
                                                             $selemail="select first_name as em from basic where user_id=$withusers_id";
                                                             $rinemail=mysqli_query($dbc,$selemail);
                                                             if($rinemail)
                                                             {
                                                                 $rowemail=mysqli_fetch_array($rinemail);
                                                                 $with_ppl_name[$totwusers]=$rowemail['em'];
                                                             }
                                                         }
                                                     }
			
                                                              $selemail="select username as em from users where user_id=$withusers_id";
                                                             $rinemail=mysqli_query($dbc,$selemail);
                                                             if($rinemail)
                                                             {
				$t_usr_nm=$t_usr_nm+1;
                                                                 $rowemail=mysqli_fetch_array($rinemail);
                                                                 $with_ppl_user_name[$t_usr_nm]=$rowemail['em'];
                                                             }
			  
                                                    }

                                                }
                                            }
                                        }
		      $selma="select username as em from users where user_id=$poster_id";
                                                             $rnemai=mysqli_query($dbc,$selma);
                                                             if($rnemai)
                                                             {
                                                                 $rowema=mysqli_fetch_array($rnemai,MYSQLI_ASSOC);
                                                                 $poster_user_name=$rowema['em'];
                                                             }
                                                     
		        $qe="select med_img as m from small_pics where user_id=$poster_id";
			  $re=  mysqli_query($dbc, $qe);
			  if($re)
			  {
			         if(mysqli_num_rows($re)>0)
			         {
			                $rt=  mysqli_fetch_array($re,MYSQLI_ASSOC);
			                $p_pic=$rt['m'];
			         }else
			         {
			                $p_pic="icons/male.png";
			         }
			  }


                                        $imgc=0;
                                         $liked=0;
                                                            $mylike=0;
			         $pvs=0;
                                                                $myunlike=0;
                                                                $myrate=0;
			            
			              $q3="select like_userid as lu from post_status where post_id=$post_id ";
                                                     $r3=mysqli_query($dbc,$q3);
                                                     if($r3)
                                                     {

                                                        $lc=0;
                                                        while($rowlike=mysqli_fetch_array($r3,MYSQLI_ASSOC))
                                                        {   
                                                            $lkc=$rowlike['lu'];
			        
                                                            if($lkc<=0)
                                                            {
                                                                
                                                            }else
                                                            {
                                                                $lc=$lc+1;
                                                            }
                                                            
                                                        }
                                                     }
                                        $me1="select like_userid as lk,unlike_userid as uk,rating as rt,seen_post as pvs from post_status where post_id=$post_id and user_id=$user_id";
                                                        $rem1=mysqli_query($dbc,$me1);
                                                        if($rem1)
                                                        {
                                                           
                                                            if(mysqli_num_rows($rem1)>0)
                                                            {
                                                                $rowsx=mysqli_fetch_array($rem1,MYSQLI_ASSOC);
                                                                $mylike=$rowsx['lk'];
                                                                $myunlike=$rowsx['uk'];
                                                                $myrate=$rowsx['rt'];
			             
                                                                if($mylike==0)
                                                                {
                                                                    $mylike=0;
                                                                }else{
                                                                    $mylike=1;
                                                                }
                                                                if($myunlike==0)
                                                                {
                                                                    $myunlike=0;
                                                                }else
                                                                {
                                                                    $myunlike=1;
                                                                }
                                                                if($myrate==0)
                                                                {
                                                                    $myrate=0;
                                                                }else
                                                                {
                                                                    $myrate=$myrate;
                                                                }
                                                            }else
                                                            {
                                                                
                                                            }
                                                        }else
                                                        {
                                                              
                                                        }
                                        
                                                   $pdfcnt=0;
                                                   $filecnt=0;
                                                   
                                                    
			   $pvs=0;
                                                     $q3="select seen_post as snp from post_status where post_id=$post_id ";
                                                     $r3=mysqli_query($dbc,$q3);
                                                     if($r3)
                                                     {

                                                     
                                                        while($rowsnp=mysqli_fetch_array($r3,MYSQLI_ASSOC))
                                                        {   
                                                            $snp=$rowsnp['snp'];
			        
                                                            if($snp=="0")
                                                            {
                                                                
                                                            }else
                                                            {
                                                             $pvs=$pvs+1;
                                                            }
                                                            
                                                        }
                                                     }
                                                     $q4="select unlike_userid unk from post_status where post_id=$post_id ";
                                                     $r4=mysqli_query($dbc,$q4);
                                                     if($r4)
                                                     {
                                                        $ulc=0;
                                                        while($rowunlike=mysqli_fetch_array($r4,MYSQLI_ASSOC))
                                                        {
                                                            $ukc=$rowunlike['unk'];
                                                            if($ukc=="0")
                                                            {
                                                                
                                                            }else
                                                            {
                                                                $ulc=$ulc+1;
                                                            }
                                                            
                                                        }
                                                     }
                                                      $q5="select rating as rates from post_status where post_id=$post_id ";
                                                     $r5=mysqli_query($dbc,$q5);
                                                     if($r5)
                                                     {
                                                        $ratc=0;
                                                        while($rowrate=mysqli_fetch_array($r5,MYSQLI_ASSOC))
                                                        {
                                                            $ratec=$rowrate['rates'];
                                                            if($ratec!=="0")
                                                            {
                                                                $ratc=$ratc+1;
                                                            }
                                                            
                                                        }
                                                     }
                                                       $q6="select cmnt_id from post_comments where post_id=$post_id ";
                                                     $r6=mysqli_query($dbc,$q6);
                                                     if($r6)
                                                     {
                                                        $cmcnt=0;
                                                        while(mysqli_fetch_array($r6,MYSQLI_ASSOC))
                                                        {

                                                            $cmcnt=$cmcnt+1;
                                                        }
                                                     }
                                                     $q7="select user_id from post_download where post_id=$post_id ";
                                                     $r7=mysqli_query($dbc,$q7);
                                                     if($r7)
                                                     {
                                                        $dncnt=0;
                                                        while(mysqli_fetch_array($r7,MYSQLI_ASSOC))
                                                        {
                                                            $dncnt=$dncnt+1;
                                                        }
                                                     }
                                                       $q8="select user_id from post_share where post_id=$post_id ";
                                                     $r8=mysqli_query($dbc,$q8);
                                                     if($r8)
                                                     {
                                                        $shrcnt=0;
                                                        
                                                        while(mysqli_fetch_array($r8,MYSQLI_ASSOC))
                                                        {
                                                            $shrcnt=$shrcnt+1;
                                                        }
                                                     }
                                                    
                                                     
                                                     $res="SELECT likes as l ,unlike as u,download as dwn,comment as cm,share as sh,rating as rtres from post_response where post_id=$post_id";
                                                     $rc=mysqli_query($dbc,$res);
                                                     if($rc)
                                                     {
                                                        if(mysqli_num_rows($rc)>0)
                                                        {
                                                            while($rotg=mysqli_fetch_array($rc,MYSQLI_ASSOC))
                                                            {
                                                                $likeres=$rotg['l'];
                                                                $unlikeres=$rotg['u'];
                                                                $dwnres=$rotg['dwn'];
                                                                $cmntres=$rotg['cm'];
                                                                $shareres=$rotg['sh'];
                                                                $rateres=$rotg['rtres'];
                                                            }
                                                           
                                                        }else
                                                        {
                                                            $likeres=1;
                                                                $unlikeres=1;
                                                                $dwnres=1;
                                                                $cmntres=1;
                                                                $shareres=1;
                                                                $rateres=1;
                                                        }
                                                     }
			    $post_caption="";
                                                       $post_loc="";
                                                       $post_feel="";
                                                       $post_feelwhile="";
			     $post_time="";
                                                     $sel_con="select post_caption as pcap,post_time as t,post_location as loc,post_feelings as fl,post_feeling_while as whl from postforall where post_id=$post_id";
                                                     $rts=  mysqli_query($dbc, $sel_con);
                                                     if($rts)
                                                     {
                                                         if(mysqli_num_rows($rts)>0)
                                                         {
                                                             $my_cont_row=mysqli_fetch_array($rts,MYSQLI_ASSOC);
                                                              $post_caption=$my_cont_row['pcap'];
                                                       $post_loc=$my_cont_row['loc'];
                                                       $post_feel=$my_cont_row['fl'];
                                                       $post_feelwhile=$my_cont_row['whl'];
                                                       
                                                        $post_time=$my_cont_row['t'];
                                                         }else
                                                         {
                                                             
                                                         }
                                                     }
			  $qw="select top_meme as tpme,bottom_meme as btm_me from meme_posts where post_id=$post_id";
			  $rw=  mysqli_query($dbc,$qw);
			  if($rw)
			  {
			         if(mysqli_num_rows($rw)>0)
			         {
			                $rf=  mysqli_fetch_array($rw,MYSQLI_ASSOC);
			                $top_meme=$rf['tpme'];
			               
			                $btm_meme=$rf['btm_me'];
			                 $top_meme='<div class="pstop_meme">'.$top_meme.'</div>';
			                $btm_meme='<div class="psbtm_meme">'.$btm_meme.'</div>';
			                
			         }  else {
			         $top_meme="";
			                $btm_meme="";
			                       
			         }
			  }
                                                     $q2="select disc as s,category as ct from post_ctgry where post_id=$post_id";
                                                     $r2=mysqli_query($dbc,$q2);
                                                     if($r2)
                                                     {
                                                         $ctgry=0;
			      $my_category=0;
                                                             
                                                         if(mysqli_num_rows($r2)>0)
                                                         {
                                                             $ctgry=1;
			       
                                                             $rod=  mysqli_fetch_array($r2,MYSQLI_ASSOC);
                                                             $discr=$rod['s'];
			             $my_category=$rod['ct'];
                                                             
                                                         }else
                                                         {
                                                             $discr="";
                                                         }
                                                     }
			  
			  if($officiale==1)
			  {
			         $q="";
			  }
			  $post_images=array();
			  $tot_files=array();
                                                     $qer="select post_image as img from post_images where post_id=$post_id";
                                                     $rer=  mysqli_query($dbc, $qer);
                                                     if($rer)
                                                     {
                                                         $ns=0;
                                                  $tot_fls=0;
                                                         if(mysqli_num_rows($rer)>0)
                                                         {
                                                            while($img_row=  mysqli_fetch_array($rer,MYSQLI_ASSOC))
                                                            {
                                                                $ns=$ns+1;
			             $tot_fls=$tot_fls+1;
                                                                $post_images[$ns]=$img_row['img'];
			             $tot_files[$tot_fls]=$img_row['img'];
                                                     
                                                    
                                                            }
                                                                
                                                    
                                                         }
                                                     }
                                                      
                                        $selppost="select post_audio as aud,post_video as v,post_file as fl,post_pdf as pdf,thumb_nails as thm from post_files where post_id=$post_id";
                                       
                                        $runselpost=mysqli_query($dbc,$selppost);
                                        if($runselpost)
                                        {
                                            $n=0;
                                                  
                                                       $post_pdfs=array();
			    $post_files=array();
			    $post_videos=array();
			    $post_audios=array();
			    $thum_nails=array();
			    
			    $pdf_ct=0;
			    $aud_ct=0;
			    $vid_ct=0;
			    $file_ct=0;
			    $tm_ct=0;
                                            if(mysqli_num_rows($runselpost)>0)
                                            {
                                                
                                                while ($rowofcurpost=mysqli_fetch_array($runselpost,MYSQLI_ASSOC))
                                                {
                                                   
                                                    $post_video=$rowofcurpost['v'];
                                                        $post_audio=$rowofcurpost['aud'];
                                                        $post_file=$rowofcurpost['fl'];
                                                        $post_pdf=$rowofcurpost['pdf'];
			     $thum_nail=$rowofcurpost['thm'];
                                                        
			     if(strpos($post_pdf,"pdfs/")>0)
			     {
			            $pdf_ct=$pdf_ct+1;
			            $tot_fls=$tot_fls+1;
			            $post_pdfs[$pdf_ct]=$post_pdf;
			            $tot_files[$tot_fls]=$post_pdf;
			     }
			     if(strpos($post_file,"files/")>0)
			     {
			            $file_ct=$file_ct+1;
			                $tot_fls=$tot_fls+1;
			            $post_files[$file_ct]=$post_file;
			            $tot_files[$tot_fls]=$post_file;
			            
			     }
			     if(strpos($post_video,"post/videos")>0)
			     {
			            $vid_ct=$vid_ct+1;
			             $tot_fls=$tot_fls+1;
			            $post_videos[$vid_ct]=$post_video;
			            $tot_files[$tot_fls]=$post_video;
			            $thum_nails[$tm_ct]=$thum_nail;
			     }
			     
			     if(strpos($post_audio,"post/audio")>0)
			     {
			            $aud_ct=$aud_ct+1;
			              $tot_fls=$tot_fls+1;
			            $post_audios[$aud_ct]=$post_audio;
			            $tot_files[$tot_fls]=$post_audio;
			     }
			     
                                                    
                                                 
                                                  
                                                }
                                                
                                            }
                                        }
                                        
                                        
                                                     $uname="select c_name as fname from contacts where user_id=$user_id and  cu_id=$poster_id";
                                                     $runnm=mysqli_query($dbc,$uname);
                                                     if($runnm)
                                                     {
                                                         if(mysqli_num_rows($runnm)>0)
                                                         {
                                                             $rownm=mysqli_fetch_array($runnm);
                                                             $poster_name=$rownm['fname'];
                                                         }else{
                                                             $selemail="select first_name as em from basic where user_id=$poster_id";
                                                             $rinemail=mysqli_query($dbc,$selemail);
                                                             if($rinemail)
                                                             {
                                                                 $rowemail=mysqli_fetch_array($rinemail);
                                                                 $poster_name=$rowemail['em'];
                                                             }
                                                         }
                                                     }
                                          
                                     
                                        $q="select allpeople as p,me as me,allrelation as ar,friends as f,family as fm,secret as cm,showonlyto as sh,hideeto as hd,me as m,special as spl from post_permision where post_id=$post_id";
                                        $r=mysqli_query($dbc,$q);
                                        if($r)
                                        {
                                            $row=mysqli_fetch_array($r,MYSQLI_ASSOC);
                                            $allppl=$row['p'];
                                            $allrel=$row['ar'];
                                            $friends=$row['f'];
                                            $family=$row['fm'];
                                            $classmate=$row['cm'];
                                            $sonto=$row['sh'];
                                            $hideto=$row['hd'];
                                            $special=$row['spl'];
                                            $me=$row['me'];
                                        }
                                        if($me==1)
                                        {
                                            if($poster_id==$user_id)
                                            {
                                                $iam=1;
                                            }else
                                            {
                                                $iam=0;
                                            }
                                        }else
                                        {
                                            $iam=0;
                                        }
                                        if($hideto==1)
                                         {
                                                $q="select hideto as h from post_forsomeppl where post_id=$post_id and hideto='$user_id'";
                                                $r=mysqli_query($dbc,$q);
                                                if($r)
                                                { $hd=0;
                                                    if(mysqli_num_rows($r)>0)
                                                    {
                                                        $hd=1;
                                                    }
                                                }
                                            }else
                                            {
                                                $hd=0;
                                            }
                                            
                                            $q="select showonlyto as sf from post_forsomeppl where post_id=$post_id and showonlyto='$user_id'";
                                            $r=mysqli_query($dbc,$q);
                                            if($r)
                                            {
                                                $shonto=0;
                                                if(mysqli_num_rows($r)>0)
                                                {
                                                    $shonto=1;
                                                }
                                            }
                                            if($hd==1)
                                            {
			
                                            }else
                                            {
                                        
                                        if($allppl==1 || $shonto==1 || $iam==1)
                                        {
                                        allpost($btm_meme,$top_meme,$thum_nails,$tot_files,$post_pdfs,$post_audios,$post_videos,$post_files,$shared_name,$shared_user_name,$shared_time,$post_images,$pvs,$post_loc,$post_feel,$post_feelwhile,$officiale,$with_ppl_user_name,$with_ppl_name,$poster_user_name,$p_pic,$post_id,$poster_id,$post_caption,$post_time,$poster_name,$imgc,$cnt,$lc,$ulc,$ratc,$cmcnt,$dncnt,$shrcnt,$mylike,$myunlike,$myrate,$likeres,$unlikeres,$dwnres,$cmntres,$shareres,$rateres,$ctgry,$discr,$shared_with_userid,$shared_to_me,$c_name,$shared_userid,$tot_num_post, $next_postid,$prev_postid,$page_name,$my_category,$page_id,$tot_cnt);
                                        }else
                                         {
                                            
                                            if($allrel==1)
                                            {
                                                 $q="select cu_id as c from contacts where user_id=$poster_id and cu_id=$user_id";
                                                $r=mysqli_query($dbc,$q);
                                                if($r)
                                                {
                                                    if(mysqli_num_rows($r)>0)
                                                    {
                                                        allpost($btm_meme,$top_meme,$thum_nails,$tot_files,$post_pdfs,$post_audios,$post_videos,$post_files,$shared_name,$shared_user_name,$shared_time,$post_images,$pvs,$post_loc,$post_feel,$post_feelwhile,$officiale,$with_ppl_user_name,$with_ppl_name,$poster_user_name,$p_pic,$post_id,$poster_id,$post_caption,$post_time,$poster_name,$imgc,$cnt,$lc,$ulc,$ratc,$cmcnt,$dncnt,$shrcnt,$mylike,$myunlike,$myrate,$likeres,$unlikeres,$dwnres,$cmntres,$shareres,$rateres,$ctgry,$discr,$shared_with_userid,$shared_to_me,$c_name,$shared_userid,$tot_num_post, $next_postid,$prev_postid,$page_name,$my_category,$page_id,$tot_cnt);
                                        
                                                    }
                                                }
                                            }else
                                            {
                                                       
                                            }
                                            
                                        
                                }
                                            }
                                       
                                }
                            }
                        }
	       
	        echo '        
                    
                </div>
               
            </div>
        </div>';
	        include('../web/notifs.html');
                
                include 'online.php';
}
 ?>
