<?php 
{
       
         $user_id=$_SESSION['user_id'];
         require_once 'mysqli_connect.php'; 
          $q3="select first_name as f from basic where user_id=$user_id";
	 $r3=  mysqli_query($dbc, $q3);
	 if($r3)
	 {
	        if(mysqli_num_rows($r3)>0)
	        {
	               $rt=  mysqli_fetch_array($r3,MYSQLI_ASSOC);
	               $my_name=$rt['f'];
	        }else
	        {
	               $my_name="some one";
	        }
	 }
	     $q="select update_pics as p from profile_pics where user_id=$user_id order by pic_id desc limit 1";
                      $r=mysqli_query($dbc,$q);
                      if($r)
                      {
                          
                          if(mysqli_num_rows($r)>0)
                          {
                              $rpw=mysqli_fetch_array($r,MYSQLI_ASSOC);
                              $ppics=$rpw['p'];
                              
                              
                          }  else {
                                $ppics="../web/icons/male.png"; 
                          }
                      }
	     
	            $q="select prof_Theme as thm,theme_txt_color as theme_txt_color from settings_profile where user_id=$user_id";
           $r=  mysqli_query($dbc, $q);
           if($r)
           {
	 if(mysqli_num_rows($r)>0)
	 {
	      $roed=  mysqli_fetch_array($r,MYSQLI_ASSOC);
	      $theme=$roed['thm'];
	      $theme_txt_color=$roed['theme_txt_color'];
	 }else
	 {
	        $theme="#008b8b";
	        $theme_txt_color="#ffffff";
	        
	        
	 }
	  $_SESSION['theme_color']=$theme;
	        $_SESSION['txt_color']=$theme_txt_color;
	       
           }
           $_SESSION['theme_color']=$theme;
	        $_SESSION['txt_color']=$theme_txt_color;
	       $q="select lock_pass as lp,locked as lk from person_config where user_id=$user_id";
	       $r=  mysqli_query($dbc,$q);
	       if($r)
	       {
	              if(mysqli_num_rows($r)>0)
	              {
		    $row=  mysqli_fetch_array($r,MYSQLI_ASSOC);
		    $password=$row['lp'];
		    $locked=$row['lk'];
	              }  else {
		$locked=0;    
	              }
	       }
	       
         echo '<!DOCTYPE html>
<html>
 <head>
    <link rel="stylesheet" href="../web/'.$_SESSION['css'].'mainBar.css"/>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
   <script src="../web/mainBar.js" type="text/javascript"></script>
  </head>
  
  <body onload="showPageLoadStatus()" >
      <div id="content-full">
          <script>
              $(function() {
  $(\'a[href*=#]:not([href=#])\').click(function() {
    if (location.pathname.replace(/^\//,\'\') == this.pathname.replace(/^\//,\'\') && location.hostname == this.hostname) {
      var target = $(this.hash);
      target = target.length ? target : $(\'[name=\' + this.hash.slice(1) +\']\');
      if (target.length) {
        $(\'html,body\').animate({
          scrollTop: target.offset().top
        }, 1000);
        return false;
      }
    }
  });
});

       
          </script>
           <input type="hidden" value="'.$password.'" id="lock_pass" />
          <div id="SedFed_PageStatus">
              <input type="hidden" value="Name" id="srchthis" />
                <div id="SF_OpeningLogo">SedFed</div>
                <div id="SF_pageLoadStatus">
                    <div id="SF_pageLiveLoadedStatus" ></div>
                </div>
          </div>
         
          <div id="SF_BigSearch" class="BigSearchBarOut" style="display: none;" >
          <div class="BigSearchBarIn">
             <input type="text" id="SF_inpBigSrch" class="search_sedfed" oninput="searchsedfed(this.value);" onblur="$(\'.SF_BigSrchResultOut\').fadeOut();" onclick="$(\'.SF_BigSrchResultOut\').fadeIn();" placeholder="Search People on SedFed ..." />
              
                <script>
                  function srchInp(){
                      $(\'.SFTB_srchInp\').val($(\'#SF_inpBigSrch\').val());
                      if($(\'#SF_inpBigSrch\').val()===\'\'){
                          $(\'#SF_SearchSugg\').slideUp();
                          
                      }
                      else{
                          $(\'#SF_SearchSugg\').slideDown();
                      }
                  }
	 
	 ';
	 if($locked==1)
	 {
	        echo '$(document).ready(function()
		 {
		 
		 $(\'#SedFedLockScreenOut\').slideDown();
		 });';
	        }  else {
	       echo '$(document).ready(function()
		 {
		 $(\'#SedFedLockScreenOut\').slideUp();
		 });';       
	        }
	 echo '
                  </script>
	 
            
                  <div class="BigSearchType">
                      <select onchange="BigSrchTypeSelcted(\'#BigSearchTypeSlct\')" id="BigSearchTypeSlct" >
                          <option value="People" >People</option>
                          <option value="Posts" >Posts</option>
                          <option value="Messages" >Messages</option>
                          <option value="FlashNews" >Flash News</option>
                          <option value="Pages" >Group/Page</option>
                          
                          
                      </select>
                  </div>
                  
                  <!-- don\'t change id\'s of any filter used in jquery -->
                  <input type="hidden" value="Name" id="srchthis" />
                  <div class="BigSearchTypeFilters" id="BST_People" style="display: block;" >
                      <select onchange="$(\'#srchthis\').val(this.value);$(\'.search_sedfed\').attr(\'placeholder\',\'Search by \'+this.value+\'\');">
                          <option>Name</option>
                          <option>SedFed ID</option>
                          <option>Mobile No</option>
                          <option>Email</option>
                          <option>Place</option>
                          <option>School / College</option>
                          
                      </select>
                  </div>
                  <div class="BigSearchTypeFilters" id="BST_Posts" style="display: none;" >
                      <select onchange="$(\'#srchthis\').val(this.value);$(\'.search_sedfed\').attr(\'placeholder\',\'Search by \'+this.value+\'\');">
                          <option>Poster Name</option>
                          <option>Post ID</option>
                          <option>Post Caption</option>
                          <option>HashTag</option>
                          <option>@-Tag</option>
                      </select>
                  </div>
	  <div class="BigSearchTypeFilters" id="BST_Pages" style="display: none;" >
                      <select onchange="$(\'#srchthis\').val(this.value);$(\'.search_sedfed\').attr(\'placeholder\',\'Search by \'+this.value+\'\');">
                          <option>Group/Page Name</option>
                          <option>Group/Page ID</option>
                          
                      </select>
                  </div>
	
                  <div class="BigSearchTypeFilters" id="BST_Messages" style="display: none;" >
                      <select onchange="$(\'#srchthis\').val(this.value);$(\'.search_sedfed\').attr(\'placeholder\',\'Search by \'+this.value+\'\');">
                          <option>Sender Name</option>
                          <option>Message Text</option>
                          
                      </select>
                  </div>
                  <div class="BigSearchTypeFilters" id="BST_FlashNews" style="display: none;" >
                      <select onchange="$(\'#srchthis\').val(this.value);$(\'.search_sedfed\').attr(\'placeholder\',\'Search Flash news by \'+this.value+\'\');">
                          <option>Flash Message</option>
                          <option>Name of Person</option>
                          <option>Flash ID</option>
                          
                      </select>
                      
                  </div>
                  <div class="closeBigSearch" onclick="$(\'#SF_BigSearch\').fadeOut();" >
                          X
                      </div>
              <div class="BS_Prcd" title="Search">
                  <img class="ico_TtlBarSrch" alt="Search"  src="../web/icons/mainBar/search.png" onclick="search_full()" />
              </div>
          </div>
      </div>
      <div class="SF_BigSrchResultOut" id="SF_SearchSugg" style="display: none;" >
          <div id="srch_result_cont"></div>
          <div id="for_show_all_result" onclick="search_full()">Show all results about this</div>
      </div><div id="mob_no_tip" style="display:none;">You have enter minimum 8 digit number</div>
          <div class="SedFedTitleBar" >
             <div class="SedFedLogo">
                <div id="sedfedLogoTop"></div>
                <div id="sedfedLogoProgress"></div>
            </div>
              <div class="TitleBarOut" style="background-color:'.$_SESSION['theme_color'].';color:'.$_SESSION['txt_color'].'">
                  <div class="TtlBarIn">
                      <div class="TtlBarTtl"  >
                          <img class="TopProfPic" src="'.$ppics.'" alt="SedFed"/>
                          <a href="../'.$_SESSION['user_name'].'" target="_blank"><div class="SedFedUserName">'.$my_name.'  </div></a>
                      </div>
                      <div class="TtlBar_SrchHold">
                          <div class="SFTB_srchIn">
                              <input class="SFTB_srchInp" type="text" placeholder="Search People , Posts , Etc.," autofocus onclick="$(\'#SF_BigSearch\').show();$(\'#SF_inpBigSrch\').focus();" />
                               <img class="ico_TtlBarSrch" src="../web/icons/mainBar/search.png"   />
                          </div>
                          <div class="SFTB_searchSubmit">
                             
                          </div>
                      </div>
                 
              <a href="../web/globe.php"><div class="SFTB_searchSubmit">
                             <b ><font color="white">Home</font></b>
                          </div></a>
                      <div class="TtlBarAccountActs">
                          <div class="TtlBarACactIn">
                              
                              <div class="TACT_Logout" onclick="$(\'#MyAccountAct\').slideToggle();" >
                                  <img class="ico_sf_Logout"  src="../web/icons/mainBar/powerB.png" alt="Logout" />
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="AccountActsHold" id="MyAccountAct" style="display: none;" >
                      <div class="AccountActsItm">
                          <div class="TACT_Lock" onclick="lock_my_screen()" title="Lock">
                                  <img class="ico_sf_Lock"  src="../web/icons/mainBar/lock.png" alt="Lock" />
                          </div>
                          <div class="TACT_Lock" title="Logout">
                                <a href="logout.php" > <img class="ico_sf_LogOut"  src="../web/icons/mainBar/logout.png" alt="Logout" /></a>
                          </div>
                      </div>
                  </div>
                 
              </div>
          </div>
           <div class="SedFed_leftMouseChecker" onmouseover="showMyAccLeftPane()" >
              
          </div>
          <div class="SedFedMainBar" id="MyAccLeftPane" >
              <div class="MainBarOut">
                  <div class="MainBarIn">
                     
                      <div class="ToolTipMainBarHold" id="MainBarToolTip" style="display: none;" >
                          <div class="TtMBArr"></div>
                          <div class="TtMBCont" id="MainBarTtTxt" >
                              Click to Update
                          </div>
                      </div>
                     <a href="../'.$user_id.'"> <div class="MainBarItm">
                          <img class="ico_sf_mBar" src="../web/icons/mainBar/profile.png"  onmouseover="meOnMainBar(event,\'Profile\')" onmouseout="meOutMainBar()"/>
                      </div></a>
                      <a href="../web/people.php"><div class="MainBarItm">
                          <img class="ico_sf_mBar" src="../web/icons/mainBar/people.png"  onmouseover="meOnMainBar(event,\'People\')" onmouseout="meOutMainBar()"/>
                      </div></a>
                      <a href="../web/my_messages.php"><div class="MainBarItm">
                          <img class="ico_sf_mBar" src="../web/icons/mainBar/messages.png" onmouseover="meOnMainBar(event,\'Messages\')" onmouseout="meOutMainBar()"/>
                      </div></a>
                   <!--   <div class="MainBarItm">
                          <img class="ico_sf_mBar" src="../web/icons/mainBar/bulbs.png" title="Profile"/>
                      </div> -->
                     <a href="../web/people_post.php?user='.$user_id.'" ><div class="MainBarItm">
                          <img class="ico_sf_mBar" src="../web/icons/mainBar/myposts.png"  onmouseover="meOnMainBar(event,\'My Posts\')" onmouseout="meOutMainBar()"/>
                      </div></a>
                     <a href="../web/globe.php"><div class="MainBarItm">
                          <img class="ico_sf_mBar" src="../web/icons/mainBar/whatsup.png"  onclick="$(\'#PostAuditorium\').fadeIn();" onmouseover="meOnMainBar(event,\' What\'s Up \')" onmouseout="meOutMainBar()"/>
                      </div></a>
                     <a href="../'.$_SESSION['user_name'].'/storage.php"> <div class="MainBarItm">
                          <img class="ico_sf_mBar" style="max-height:27px;" src="../web/icons/mainBar/folder.png"  onmouseover="meOnMainBar(event,\'My Storage\')" onmouseout="meOutMainBar()"/>
                      </div></a>
                    <!--  <div class="MainBarItm">
                          <img class="ico_sf_mBar" style="max-height:15px;" src="../web/icons/mainBar/password.png" title="Profile"/>
                      </div> -->
                     <a href="../web/settings.php"> <div class="MainBarItm">
                          <img class="ico_sf_mBar" style="max-height:27px;" src="../web/icons/mainBar/settings.png" onmouseover="meOnMainBar(event,\'Settings\')" onmouseout="meOutMainBar()"/>
                      </div> </a>
                  <!--    <div class="MainBarItm">
                          <img class="ico_sf_mBar" style="max-height:30px;" src="../web/icons/mainBar/lock.png" title="Lock"/>
                      </div>
                      <div class="MainBarItm">
                          <img class="ico_sf_mBar" style="max-height:23px;" src="../web/icons/mainBar/power.png" title="Logout"/>
                      </div> -->
                  </div>
              </div>
          </div>
          <div id="mainBarSafetyLayer" onmouseover="hideMyAccLeftPane()" ></div>
          <div id="SedFedLockScreenOut" style="display: none;" >
              <div class="SedFedLockScreenIn">
                  <div class="SF_LockScreenCont">
                      
                      <div class="SF_LockScreenFace">
                          
                          <img class="Sf_LockScreenImg" src="'.$ppics.'" />
                          
                      </div>
                      <div class="SF_LockScreenDets">
                          <div class="SF_LockScreenUsrName">
                              <div class="SF_LS_Usr">
                                  '.$my_name.' 
                              </div>
                              <div class="SF_LS_Logout" title="Logout">
                                   <img class="ico_sf_Logout"  src="../web/icons/mainBar/powerB.png" />
                              </div>
                          </div>
                          <div class="SF_LockScreenFocus">
                              <input class="SF_LS_pass_Inp" id="SF_LS_password" oninput="checkPass()" onblur="checkLockPass()"  type="password" placeholder=" * * * " />
                              <div class="SF_LS_Pass_Submit" onclick="checkPass()" ></div>
                              
                          </div>
                          <div class="SF_LS_passAlert" title="Login password or Lockscreen Password">
                              <span id="SF_LS_AlertTxt"> Password to Unlock </span> 
                          </div>
                      </div>
                       
                      
                  </div>
              </div>
             
              <div class="SedFedLS_Logo">
                  SedFed
               </div> <div id="SedFed_SearchTheater" style="display:none;" >
              <div class="SedFed_ThSrchIn">
                  <div class="SearchThtrClose" onclick="$(\'#SedFed_SearchTheater\').slideUp();" >X</div>
                 <!--
	  <div class="SearchCatogs">
                      Search In
                      <div class="SearchCatogItm">
                          <input class="srchCatChk" id="Chk_SrchPpl" type="checkbox" onchange="SrchCatSelected(\'Chk_SrchPpl\',\'#SrchTipPpl\')" checked /> People
                      </div>
                      <div class="SearchCatogItm">
                          <input class="srchCatChk" id="Chk_SrchPost" type="checkbox" onchange="SrchCatSelected(\'Chk_SrchPost\',\'#SrchTipPost\')" /> Posts
                      </div>
                      <div class="SearchCatogItm">
                          <input class="srchCatChk" id="Chk_SrchFlash" type="checkbox" onchange="SrchCatSelected(\'Chk_SrchFlash\',\'#SrchTipFlash\')" /> Flash News
                      </div>
                      <div class="SearchCatogItm">
                          <input class="srchCatChk" id="Chk_SrchMsg" type="checkbox" onchange="SrchCatSelected(\'Chk_SrchMsg\',\'#SrchTipMsg\')" /> Messages
                      </div>
                      <div class="SearchCatogItm">
                          <input class="srchCatChk" id="Chk_SrchNotif" type="checkbox"  onchange="SrchCatSelected(\'Chk_SrchNotif\',\'#SrchTipNotif\')"/> Notification
                      </div>
                  </div> 
                  <div class="SedFed_ThSrchTtl">People</div> -->
                  <div class="SF_ThSrchResults">
                    
                      <div class="SrchResTip" id="SrchTipPpl" style="display: none">
                          <div class="SrchTipTtl"> You can Search By  </div> 
                          <div class="SrchTipCont">
                              <div class="SrchTipItm"> User ID Number ( Best Result ) </div>
                              <div class="SrchTipItm"> Name of Person </div>
                              <div class="SrchTipItm"> Email / Mobile </div>
                              <div class="SrchTipItm"> School / College </div>
                              <div class="SrchTipItm"> Place </div>
                              
                          </div>
                      </div>
                      <div class="SrchResTip" id="SrchTipPost" style="display: none" >
                          <div class="SrchTipTtl"> You can Search By  </div> 
                          <div class="SrchTipCont">
                              <div class="SrchTipItm"> Post ID Number ( Best Result ) </div>
                              <div class="SrchTipItm"> Name of Person </div>
                              <div class="SrchTipItm"> Post Caption </div>
                              
                              
                          </div>
                      </div>
                      <div class="SrchResTip" id="SrchTipFlash" style="display: none" >
                          <div class="SrchTipTtl"> You can Search By  </div> 
                          <div class="SrchTipCont">
                              <div class="SrchTipItm"> Flash ID Number ( Best Result ) </div>
                              <div class="SrchTipItm"> Name of Person </div>
                              <div class="SrchTipItm"> Flash Message </div>
                          </div>
                      </div>
                      <div class="SrchResTip" id="SrchTipMsg" style="display: none" >
                          <div class="SrchTipTtl"> You can Search By  </div> 
                          <div class="SrchTipCont">
                              <div class="SrchTipItm"> Sender Name </div>
                              <div class="SrchTipItm"> Message Text </div>
                              
                          </div>
                      </div>
                      <div class="SrchResTip" id="SrchTipNotif" style="display: none" >
                          <div class="SrchTipTtl"> You can Search By  </div> 
                          <div class="SrchTipCont">
                              <div class="SrchTipItm"> Sender Name </div>
                              <div class="SrchTipItm"> Notification Text </div>
                          </div>
                      </div>
                  </div>
                  
              </div>
          </div></div></body></html>';
         
}
?>