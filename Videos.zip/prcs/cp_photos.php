<?php
require 'mysqli_connect.php';
$q="select username as u  from users ";
$r=  mysqli_query($dbc, $q);
if($r)
{
       if(mysqli_num_rows($r)>0)
       {
              while($row=  mysqli_fetch_array($r,MYSQLI_ASSOC))
              {
	    $usernm=$row['u'];
	    copy("forprofile/profile.php", "../$usernm/profile.php");
	    copy("forprofile/index.php", "../$usernm/index.php");
	    copy("forprofile/photos.php", "../$usernm/photos.php");
             copy("forprofile/videos.php", "../$usernm/videos.php");
             copy("forprofile/files.php", "../$usernm/files.php");
             copy("forprofile/wall.php", "../$usernm/wall.php");
              }
       }
}