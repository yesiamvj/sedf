function updtmynm()
{
	
	var curname=$("#inp_thName").val();
	var xmlhttp = new XMLHttpRequest();
	var name_cont="fnm="+curname;
        xmlhttp.onreadystatechange = function() {
        
            if (xmlhttp.readyState===4 && xmlhttp.status===200) {
	  alertTt(xmlhttp.responseText);
	  $("#ThName").fadeOut();
           }
          };
            xmlhttp.open("POST","updtcurname.php?"+name_cont,true);
            xmlhttp.send();

}

function updtnicknm()
{
	
	var curname=$("#inp_NickName").val();
	var xmlhttp = new XMLHttpRequest();
	var name_cont="nicknm="+curname;
        xmlhttp.onreadystatechange = function() {
        
            if (xmlhttp.readyState===4 && xmlhttp.status===200) {
	  alertTt("Updated");
	  $("#ThNickName").fadeOut();
           }else{
      
            }
          }
            xmlhttp.open("POST","updtnicknm.php?"+name_cont,true);
            xmlhttp.send();

}
function updatdob()
{
	var day=$("#inpTh_Date").val();
	var mon=$("#inpTh_Mon").val();
	var year=$("#myyear").val();
	var myage=2015-year;
	$('#myages').html("Age : "+myage);
	var xmlhttp = new XMLHttpRequest();
	var dob_cont="d="+day+"&m="+mon+"&y="+year+"&a="+myage;
        xmlhttp.onreadystatechange = function() {
        
            if (xmlhttp.readyState===4 && xmlhttp.status===200) {
	  alertTt("Updated");
	  $('#inp_DOB').val(day +" "+mon+" "+year);
	  $("#ThAge").fadeOut();
           }else{
      
            }
          }
            xmlhttp.open("POST","updtdob.php?"+dob_cont,true);
            xmlhttp.send();
}
function updtrship()
{
	var stat=$("#thRelSlct").val();
	var orrel=$("#inp_thtrRelSts").val();
	var withrl=$("#inp_thtrRelWith").val();
	var rel_cont="status="+stat+"&orany="+orrel+"&withrel="+withrl;
		var xmlhttp = new XMLHttpRequest();
	    xmlhttp.onreadystatechange = function() {
        
            if (xmlhttp.readyState===4 && xmlhttp.status===200) {
alertTt("Updated");
$("#thtrRelSts").fadeOut();
           }
          }
            xmlhttp.open("POST","updtrelstat.php?"+rel_cont,true);
            xmlhttp.send();
}
function updtloc(a)
{
	var place=$("#inp_Flocate").val();
	
	var loc_cont="iamas="+place;
	var xmlhttp = new XMLHttpRequest();

	    xmlhttp.onreadystatechange = function() {
        
            if (xmlhttp.readyState===4 && xmlhttp.status===200) {
	  alertTt("Updated");
	  $("#ThLocate").fadeOut();
           }
          };
            xmlhttp.open("POST","updtcurloc.php?"+loc_cont,true);
            xmlhttp.send();


}
function chng_bgm()
{
         var filei="#for_bgm_updt";
     var file_dat = $(filei).prop('files')[0]; 
     var fmds=new FormData();
     fmds.append('file',file_dat);
         var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
        if(xmlhttp.readyState===4 && xmlhttp.status===200) {
             $("#updtbgm").html(xmlhttp.responseText);
           alertTt("Updated");
           }else{
            }
          }
            xmlhttp.open("POST","chng_bgm.php",true);
            xmlhttp.send(fmds);
}
function preview_my_pic(pic,its_id)
{
       var r=new FileReader();
       var fmdt=new FormData();
       r.onload=(function(e)
       {
              if(its_id=="emptyWallPic")
              {
              $(its_id).css({"background-image":"url("+e.target.result+")"});
      
              }else
              {
	     $(its_id).html('<img src="'+e.target.result+'" style="max-width:100px;"/>');
	    fmdt.append('p_pic',$("#my_prof_pic").prop('files')[0]); 
	    var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
        if(xmlhttp.readyState===4 && xmlhttp.status===200) {
         $(its_id).html(xmlhttp.responseText);  
           }else{
            }
          }
            xmlhttp.open("POST","updt_prof_pic.php",true);
            xmlhttp.send(fmdt);
              }
           });
       r.readAsDataURL(pic.files[0]);
}
function thtrInput(src,trgt){
    $(trgt).val($(src).val());
    if($(src).val()=="Unmarried"|| $(src).val()=="Single"  || $(src).val()=="Divorced")
    {
    
    	$("#rmvtmp").hide();
    }else
    {
    	$("#rmvtmp").show();
    }//inp_thtrRelSts
    if($(src).val()=="Married" || $(src).val()=="In love" )
    {
    
    	$("#rmvao").hide();
    }else
    {
    	$("#rmvao").show();
    }
}
function openchengepic()
{
         $('#chngppic').fadeIn();
 var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
        if(xmlhttp.readyState===4 && xmlhttp.status===200) {
             $("#chngppic").html(xmlhttp.responseText).fadeIn();
    
           }else{
             
            }
          }
            xmlhttp.open("POST","../../web/chngpropic.php?",true);
            xmlhttp.send();
}
function change_wall_pic()
{
         $('#chngppic').fadeIn();
     var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
        if(xmlhttp.readyState===4 && xmlhttp.status===200) {
             $("#chngppic").html(xmlhttp.responseText);
             $('#chngppic').fadeIn();
           }else{
             
            }
          }
            xmlhttp.open("POST","change_wpic_edit_prof.php",true);
            xmlhttp.send();
}
function open_change_prof_pic()
{
         $('#chngppic').fadeIn();
          var cont="prof="+"not_in_prof";
      var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
        if(xmlhttp.readyState===4 && xmlhttp.status===200) {
             $("#chngppic").html(xmlhttp.responseText);
             $('#chngppic').fadeIn();
           }else{
             
            }
          }
            xmlhttp.open("POST","change_pic_edit_prof.php?"+cont,true);
            xmlhttp.send();  
}

function updtppic()
{
    
        $("#wchwantchng").val("1");
         var cont="prof="+"not_in_in_prof";
     var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
        if(xmlhttp.readyState===4 && xmlhttp.status===200) {
             $("#targetdiv").html(xmlhttp.responseText);
             
           }else{
             
            }
          }
            xmlhttp.open("POST","img_crop_edit_prof.php?"+cont,true);
            xmlhttp.send();
    
  
}
function openchngwallpic()
{
    $("#wchwantchng").val('2');
    var cont="prof="+"not_in_in_prof";
     var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
        if(xmlhttp.readyState===4 && xmlhttp.status===200) {
             $("#targetdiv").html(xmlhttp.responseText);
    
           }else{
             
            }
          };
            xmlhttp.open("POST","img_crop_edit_prof.php?"+cont,true);
            xmlhttp.send();
}
function showmy_pre_pics()
{
    $("#targetdiv").html("Loading Please wait...");
    
      var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
        if(xmlhttp.readyState===4 && xmlhttp.status===200) {
             $("#targetdiv").html(xmlhttp.responseText);
            
           }else{
            }
          }
            xmlhttp.open("POST","showmyprepics.php?",true);
            xmlhttp.send();
}
function set_selected_pic(as,nm)
{
    var mes=0;
    if(nm==="me")
    {
        mes=1;
    }
    var conts="q="+as+"&mes="+mes;
             $("#targetdiv").html("<img src=\"icons/LoaderIcon.gif\" /><br/>Please wait ...");
      var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
        if(xmlhttp.readyState===4 && xmlhttp.status===200) {
             $("#targetdiv").html(xmlhttp.responseText);
             
           
           }else{
            }
          }
            xmlhttp.open("POST","set_slctd_pic.php?"+conts,true);
            xmlhttp.send();
}
function showmy_pre_wall_pics()
{
      $("#targetdiv").html("Loading Please wait...");
    
      var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
        if(xmlhttp.readyState===4 && xmlhttp.status===200) {
             $("#targetdiv").html(xmlhttp.responseText);
            
           }else{
            }
          }
            xmlhttp.open("POST","showmy_pre_wall_pics.php?",true);
            xmlhttp.send();
}
function set_selected_wall_pic(as,c)
{
    var me=0;
    if(c==="me")
    {
        me=1;
    }
    var cont="q="+as+"&mes="+me;
     $("#targetdiv").html("<img src=\"icons/LoaderIcon.gif\" /><br/>Please wait ...");
      var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
        if(xmlhttp.readyState===4 && xmlhttp.status===200) {
             $("#targetdiv").html(xmlhttp.responseText);
             
           
           }else{
            }
          }
            xmlhttp.open("POST","set_slctd_wall_pic.php?"+cont,true);
            xmlhttp.send();
}

function change_gen(gen)
{
   
      var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
        if(xmlhttp.readyState===4 && xmlhttp.status===200) {
             alertTt("Updated");
             
           
           }else{
            }
          }
            xmlhttp.open("POST","update_gen.php?sex="+gen,true);
            xmlhttp.send(); 
}