<?php
		      $user="nregr";
		       $url='videos.php?page='.urlencode($user);
		         header("location:$url");
		      ?>