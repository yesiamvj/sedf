<?php
		      $user="nregr";
		       $url='photos.php?page='.urlencode($user);
		         header("location:$url");
		      ?>