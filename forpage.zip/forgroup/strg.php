<?php
		      $usename="nregr";
		       $url='storage.php?page='.urlencode($usename);
		         header("location:$url");
		        ?>