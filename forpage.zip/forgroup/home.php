<?php 
		 $name="nregr";
		         $url='index.php?page='.urlencode($name);
			 header("location:$url");
		   ?>