<?php
		      $usename="nregr";
		       $url='files.php?page='.urlencode($usename);
		         header("location:$url");
		        ?>