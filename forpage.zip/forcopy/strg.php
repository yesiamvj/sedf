<?php
$usename=Kanth;
 $url='storage.php?pass2='.urlencode($usename);
   header("location:$url");
  ?>