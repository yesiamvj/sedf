<?php 
$usename="Kanth";
 $url='profile.php?pass1='.urlencode($usename);
         
    header("location:$url");
?>
