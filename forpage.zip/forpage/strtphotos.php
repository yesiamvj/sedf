<?php
		      $user="myrcntpage";
		       $url='photos.php?page='.urlencode($user);
		         header("location:$url");
		      ?>