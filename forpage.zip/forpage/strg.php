<?php
		      $usename="myrcntpage";
		       $url='storage.php?page='.urlencode($usename);
		         header("location:$url");
		        ?>