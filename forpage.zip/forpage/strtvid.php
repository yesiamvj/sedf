<?php
		      $user="myrcntpage";
		       $url='videos.php?page='.urlencode($user);
		         header("location:$url");
		      ?>