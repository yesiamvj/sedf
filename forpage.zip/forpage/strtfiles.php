<?php
		      $usename="myrcntpage";
		       $url='files.php?page='.urlencode($usename);
		         header("location:$url");
		        ?>