<?php
$connection = mysql_connect('localhost','root','') or die(mysql_error());
$database = mysql_select_db('2my4edge') or die(mysql_error());
?>
