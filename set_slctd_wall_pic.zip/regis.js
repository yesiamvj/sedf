function subt()
{
    alert("ok");
}