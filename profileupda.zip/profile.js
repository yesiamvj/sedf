/* 
    Created on : May 19, 2015, 8:19:49 PM
    Author     : Vijayakumar <vijayakumar at www.sedfed.com>
*/
function meOnWallppr(){
    var imgSize=$('#img-wallpaper').width();
   
        
        $('#img-wallpaper').animate({'left':'0px'},'slow');
        $('#sf-wallpprHoldr').animate({'left':'-460px'},'slow');
    
}
function setWallpaper(){
   $('#sf-wallpprHoldr').animate({'left':'0px'});
    var imgSize=$('#img-wallpaper').width();
    imgSize=imgSize-1;
    imgSize=imgSize+100;
    imgSize='-'+imgSize+'px';
    
    $('#img-wallpaper').animate({'left':imgSize},'fast');
    
}
function meOnProfile(){
    
}
function showComPeople(event,src){
    $('#commonNameIn').html($(src).html());
    $('#whoAreCommonNames').show().css({'top':event.pageY+5,'left':event.pageX-15});
}
function expandMyMore(showt,tiltarr){
    $(showt).slideToggle();
    //alert($(tiltarr).css('transform'));
    if($(tiltarr).css('transform')==='matrix(1, 0, 0, 1, 0, 0)'){
        $(tiltarr).css({'transform':'rotate(90deg)'});
    }
    else{
        $(tiltarr).css({'transform':'rotate(0deg)'});
    }
}
function showMyFace(){
   if($('#myProfilePicOnWall img').css('max-height')==='150px'){
       $('#myProfilePicOnWall img').animate({'max-height':'450px','max-width':'450px','opacity':'1'},'slow');
   }
   else{
       $('#myProfilePicOnWall img').animate({'max-height':'150px','max-width':'150px','opacity':'0.5'},'slow');
   }
    
}
function showAvlothana(){
    $('#howThisPerson').toggle();
    $('#howThisPersonStuffs').toggle();
    /*var tiltarr='#img-avlothana';
    if($(tiltarr).css('transform')==='matrix(1, 0, 0, 1, 0, 0)'){
       $(tiltarr).css({'transform':'rotate(0deg)'});
    }
    else{
        
         $(tiltarr).css({'transform':'rotate(90deg)'});
    } */
}
function showMyExtra(showt,event){
   
    $(showt).toggle().css({'top':event.pageY-35});
    
}
function showMyExtraTip(showt,event){
    $(showt).show().css({'top':event.pageY-35});
}


function proposeMe(src,tarhtml){
    $('#TtPropCont').html(tarhtml).css({'line-height':'1.5'});
    $('.instantAlert').html('You Proposed Vijayakumar').show().animate({'margin-left':'0px'},'slow').animate({'opacity':'0'},10000);
}
function addToRelation(){
    var imgsrc=$('#img-makeRelation').attr('src');
 //   $('#img-makeRelation').attr({'src':'icons/prof-waiting.png'});
    if(imgsrc==='icons/prof-waiting.png'){
         $('#img-makeRelation').attr({'src':'icons/notif-add-ppl.png'});
         $('#hYT-relSts').text('No relation');
          $('#hYT-Tt-AddRelTtl').text('Add to Relation');
         $('#hyt-cont').text('Click to send a Request');
        
    }
    else{
         $('#img-makeRelation').attr({'src':'icons/prof-waiting.png'});
          $('#hYT-relSts').text($('#data-relSts').text());
          $('#hYT-Tt-AddRelTtl').text('Request Sent');
         $('#hyt-cont').text('Please wait till he accepts your Request');
         
    }
}
function Likedone(binari,county,dests){
    if(binari===1){
       var curentt=$(dests).attr('src');
       if(curentt==='icons/post-sf-like.png'){
           county=county+1;
           $('.likeCount').text(county);
            $(dests).attr({'src':'icons/post-sf-liked.png'});
       }
       else{
            $('.likeCount').text(county);
           $(dests).attr({'src':'icons/post-sf-like.png'});
       }
    }
    else{
        var curentt=$(dests).attr('src');
       if(curentt==='icons/post-sf-unlike.png'){
           county=county+1;
           $('.unlikeCount').text(county);
            $(dests).attr({'src':'icons/post-sf-unliked.png'});
       }
       else{
           
           $('.unlikeCount').text(county);
           $(dests).attr({'src':'icons/post-sf-unlike.png'});
       }
    }
}
function quickpostRateclk(srcid){
    var itemsrc;
    var prsntSrc=$(srcid).attr('src');
    if(prsntSrc==='icons/post-sf-emptyRate.png'){
         $(srcid).attr({'src':'icons/post-Qrated-1.png'});
        postRated(1,101);
       
    }
    else{
          for(i=0;i<=5;i++){
         itemsrc='icons/post-Qrated-'+i+'.png';
         if(itemsrc===prsntSrc){
            var i=i+1;
             if(i===6){
                 i=0;
                  $(srcid).attr({'src':'icons/post-sf-emptyRate.png'}); 
                 // postRated(i,101); ///pay atttenetion when finish
                  break;
             }
             else{
                 //postRated(i,101);
                  $(srcid).attr({'src':'icons/post-Qrated-'+i+'.png'});
                  break;
             }
           
             
         }
         
    }
    }  
}
$(function(){
    $(window).on('scroll',function(){
        
        
       var qua= $('#myProfilePicOnWall img').css('opacity');
       qua=qua-0.11+0.2;
       $('#myProfilePicOnWall img').css({'opacity':qua});
     
      
    });
});
