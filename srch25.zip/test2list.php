<html>
<?php
echo'< class="highELE">svg "highATT">height=>"210" "highATT">width=>"500""highGT">>
  < class="highELE">line "highATT">x1=>"0" "highATT">y1=>"0" "highATT">x2=>"200" "highATT">y2=>"200" "highATT">style=>"stroke:rgb(255,0,0);stroke-width:2" "highATT">/"highGT">>
< class="highELE">/svg"highGT">>';
?>
</html>