<?php
$usename="qwe";
 $url='files.php?username='.urlencode($usename);
   header("location:$url");
  ?>