<?php 
$usename="qwe";
 $url='wall.php?username='.urlencode($usename);
   header("location:$url");
  ?>