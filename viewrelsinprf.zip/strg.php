<?php
$usename="qwe";
 $url='storage.php?username='.urlencode($usename);
   header("location:$url");
  ?>