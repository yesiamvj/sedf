<?php
    $hit="hit iti tubtbh t thbt";
    echo $hit;
?>
